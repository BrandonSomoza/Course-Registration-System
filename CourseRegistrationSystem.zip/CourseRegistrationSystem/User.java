package CourseRegistrationSystem;

abstract class User extends Course implements java.io.Serializable {
	String username;
	String password;
	static String firstName;
	static String lastName;
	
	public User() {}
	
	public User(String name, String id, int max, int students, String i,
			int numb, String loc) {
		super(courseName, courseId, maxStudents, registeredStudents,instructor,
			sectionNumber,  location);
	}
	
	public User(String firstName, String lastName) {
		
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
}
