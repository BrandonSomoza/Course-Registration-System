package CourseRegistrationSystem;
import java.io.IOException;

public interface StudentInterface {
	public void studentViewCourses();
	public void openCourses();
	public void register() throws IOException;
	public void withdraw() throws IOException;
	public void viewRegisteredCourses();

}
