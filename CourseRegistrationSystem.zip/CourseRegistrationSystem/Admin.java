package CourseRegistrationSystem;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.*; 
import java.util.*; 

public class Admin extends User implements AdminInterface {
	static ArrayList<Student> masterList = new ArrayList<Student>();
	
	public Admin() {
		super();
		this.username = "admin";
		this.password = "admin001";
	}
	
	public ArrayList<Student> getMasterList() {
		return masterList;
	}

	public void setUsername(ArrayList<Student> masterList) {
		this.masterList = masterList;
	}
	
	public void createCourse() throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("What is the course name: ");
		courseName = in.readLine();
		
		System.out.println("What is the course ID: ");
		courseId = in.readLine();
		
		System.out.println("What is the maximum number of students registered in the course?: ");
		String maxNumber = in.readLine();
		maxStudents = Integer.parseInt(maxNumber);
		
		System.out.println("What is the current number of registered students?: ");
		String number = in.readLine();
		registeredStudents = Integer.parseInt(number);
		
		//System.out.println("What are the names of the students registered in the course?: ");
		//names = in.readLine();
		
		System.out.println("Who is the course instructor?: ");
		instructor = in.readLine();
		
		System.out.println("What is the course section number?: ");
		String s = in.readLine();
		sectionNumber = Integer.parseInt(s);
		
		System.out.println("What is the course location?: ");
		location = in.readLine();
		
		Course c = new Course(this.courseName, this.courseId, maxStudents, registeredStudents, this.instructor,
				sectionNumber, this.location);
		courseList.add(c);

		System.out.println("The course " + courseName + " has been added");
	}

	@Override
	public void deleteCourse() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("What course would you like to delete?");
		String name = in.readLine();
		
		for(int i=0; i< courseList.size(); i++) {
			String s = courseList.get(i).getCourseName(); 
			if(s.contentEquals(name)) {
				courseList.remove(i);
			}
			System.out.println("The course has been removed");
			break;
		}
	}

	@Override
	public void editCourse() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Whats the name of the course you would like to edit?");
		String n = in.readLine();
		System.out.println("Enter 'intructor' if you would like to change the instructor of the course");
		System.out.println("Enter 'location' if you would like to change the location of the course");
		String s = in.readLine();
		if(s.contentEquals("instructor")) {
			System.out.println("What is the name of the new instructor?");
			String name = in.readLine();
			for(int i=0; i<courseList.size(); i++) {
				String c = courseList.get(i).getCourseName();
				if (c.contentEquals(n)) {
					courseList.get(i).setInstructor(name);
					System.out.println("Instructor has been changed");
				}
			}
		}
		else if (s.contentEquals("location")) {
			System.out.println("What is the name of the new location?");
			String loc = in.readLine();
			for(int i=0; i<courseList.size(); i++) {
				String c = courseList.get(i).getCourseName();
				if (c.contentEquals(s)) {
					courseList.get(i).setLocation(loc);
					System.out.println("Location has been changed");
				}
			}
		}
		
		
	}

	@Override
	public void displayCourse() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("What is the course ID?");
		String id = in.readLine();
		
		for(int i =0; i<courseList.size();i++) {
			String s = courseList.get(i).getCourseId();
			if(s.contentEquals(id)) {
				courseList.get(i).print();
			}
		}
	
	
	}

	@Override
	public void registerStudent() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What is the student's first name?");
		String fname = in.readLine();
		System.out.println("What is the student's last name?");
		String lname = in.readLine();
		
		Student newStudent = new Student(firstName, lastName);
		masterList.add(newStudent);
		System.out.println("New student has been added");
	}

	@Override
	public void viewCourses() {
		// TODO Auto-generated method stub
		for(int i=0;i<courseList.size();i++) {
			courseList.get(i).print();
		}
	}

	@Override
	public ArrayList<Course> viewFullCourses() {
		// TODO Auto-generated method stub
		ArrayList<Course> coursess = new ArrayList<Course>();
		for(int i=0;i<courseList.size();i++) {
			if (courseList.get(i).getRegisteredStudents() == courseList.get(i).getMaxStudents()) {
				courseList.get(i).print();
				coursess.add(courseList.get(i));
			}
		}
		return coursess;
		
	}

	@Override
	public void writeToFileFull() {
		// TODO Auto-generated method stub
		String fileName = "MyUniversityCourses.csv";
		Scanner scan = new Scanner(System.in);
		
		try {
			FileWriter filewriter = new FileWriter(fileName);
			BufferedWriter bufferedwriter = new BufferedWriter(filewriter);
			for(int i =0; i<viewFullCourses().size(); i++) {
				String text = viewFullCourses().get(i).print();
				bufferedwriter.write(text);
				bufferedwriter.newLine();
			}
		}
		catch (IOException exk) {
			System.out.println("Error writing file '" + fileName + "'");
			exk.printStackTrace();
		}
	}

	@Override
	public void viewRegisteredStudents() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What is the course's name?");
		String courseName = in.readLine();
		
		for(int i=0; i<courseList.size();i++) {
			if(courseList.get(i).getCourseName() == courseName) {
				for(int j=0;j<studentList.size();j++) {
					String fName = courseList.get(i).getStudentList().get(j).getFirstName();
					String lName = courseList.get(i).getStudentList().get(j).getLastName();
					System.out.println("Students have been registered successfully for " + courseName);
				}
			}
		}
	}

	@Override
	public void viewStudentCourses() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("What is the student's first name?");
		String fName = in.readLine();
		System.out.println("What is the student's last name?");
		String lName = in.readLine();
		
		System.out.println("This is the list of classes that the student entered is in: ");
		for(int i=0; i<courseList.size();i++) {
			for(int j=0;j<courseList.size();i++) {
				if(courseList.get(i).getStudentList().get(j).getFirstName() == fName
						&& courseList.get(i).getStudentList().get(j).getLastName() == lName) {
					String courseName = courseList.get(i).getCourseName();
					System.out.println("- " + courseName);
				}
			}
		}
		
	}

	@Override
	public void sortCourses() {
		// TODO Auto-generated method stub
		for(int i = 0; i<courseList.size();i++) {
			for(int j = courseList.size()-1; j>i;j--) {
				if(courseList.get(i).getRegisteredStudents() > courseList.get(j).getRegisteredStudents()) {
					Course temp = courseList.get(j);
					courseList.set(i,  courseList.get(j));
					courseList.set(j, temp);
				}
			}
		}
		
	}
}
