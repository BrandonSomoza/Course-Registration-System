package CourseRegistrationSystem;
import java.util.ArrayList;
import java.io.*;
import java.util.Scanner; 

public class Course implements java.io.Serializable {
	
	static String courseName;
	static String courseId;
	static int maxStudents;
	static int registeredStudents;
	static String instructor;
	static int sectionNumber;
	static String location;
	ArrayList<Student> studentList;
	static ArrayList<Course> courseList = new ArrayList<Course>();
	
	Course() {}
	
	Course(String name, String id, int max, int students, String i,
			int number, String loc) {
		// TODO Auto-generated constructor stub
		String courseName = name;
		String courseId = id;
		int maxStudents = max;
		int registeredStudents = students;
		String instructor = i;
		int sectionNumber = number;
		String location = loc;
	}
	
	public static void serialization()
	{
	       try{
	         FileOutputStream fos= new FileOutputStream("MyUniversityCourses.csv");
	         ObjectOutputStream oos= new ObjectOutputStream(fos);
	         oos.writeObject(courseList);
	         oos.close();
	         fos.close();
	       }catch(IOException ioe){
	            ioe.printStackTrace();
	        }
	   }
	
	public static void deSerialization()
    {
        try
        {
            FileInputStream fis = new FileInputStream("MyUniversityCourses.csv");
            ObjectInputStream ois = new ObjectInputStream(fis);
            courseList = (ArrayList<Course>) ois.readObject();
            ois.close();
            fis.close();
         }catch(IOException ioe){
             ioe.printStackTrace();
             return;
          }catch(ClassNotFoundException c){
             System.out.println("Class not found");
             c.printStackTrace();
             return;
          }
   }
	
	public static void main(String [] args) throws IOException {
		ArrayList<String> s = new ArrayList<String>(); 
		
		Admin admin = new Admin();
		Scanner sc = new Scanner(new File("MyUniversityCourses.csv"));  
		sc.useDelimiter("");   //sets the delimiter pattern  
		while (sc.hasNext())  //returns a boolean value  
		{  
		System.out.print(sc.next());  //find and returns the next complete token from this scanner  
		}   
		sc.close();  
		
		try {
			FileOutputStream fos= new FileOutputStream("myfile");
	        ObjectOutputStream oos= new ObjectOutputStream(fos);
	        oos.writeObject(s);
	        oos.close();
	        fos.close();
	        System.out.print("It has been serialized");
	        }
		catch(IOException ioe){
	            ioe.printStackTrace();
	        }
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
//		System.out.println("");
//		System.out.println("Welcome to the Course Registration System");
//		System.out.println("Enter 'admin' to login as Admin");
//		System.out.println("Enter 'student' to login as Student");
//		System.out.println("Enter 'logout' to logout");
//		String input = in.readLine();
//		
//		if(input.contentEquals("admin")) {
//			System.out.println("What is the admin username?");
//			String u = in.readLine();
//			System.out.println("What is the admin password?");
//			String p = in.readLine();
			
			boolean exit = false;
			while(!exit) {
				System.out.println("");
				System.out.println("Welcome to the Course Registration System");
				System.out.println("Enter 'admin' to login as Admin");
				System.out.println("Enter 'student' to login as Student");
				System.out.println("Enter 'logout' to logout");
				String input = in.readLine();
				
				if(input.contentEquals("admin")) {
					System.out.println("What is the admin username?");
					String u = in.readLine();
					System.out.println("What is the admin password?");
					String p = in.readLine();
				System.out.println("Enter 'courses' to manage courses");
				System.out.println("Enter 'reports' to view reports");
				System.out.println("Enter 'logout' to logout");
				String input2 = in.readLine();
				
				if(input2.contentEquals("courses")) {
					System.out.println("Enter 'new course' to create a new course");
					System.out.println("Enter 'delete course' to delete a course");
					System.out.println("Enter 'edit a course' to edit a course");
					System.out.println("Enter 'display info' to display information of a course");
					System.out.println("Enter 'register student' to register a student");
					System.out.println("Enter 'logout' to logout");
					String input3 = in.readLine();
					
					if (input3.contentEquals("new course")) {
						admin.createCourse();
					} else if (input3.contentEquals("delete course")) {
						admin.deleteCourse();
					} else if (input3.contentEquals("edit a course")) {
						admin.editCourse();
					} else if (input3.contentEquals("display info")) {
						admin.displayCourse();
					} else if (input3.contentEquals("register student")) {
						admin.registerStudent();
						}
					else {
						System.out.println("Goodbye");
						exit = true;
						serialization();

						}
					}
				else if(input2.contentEquals("reports")) {
					System.out.println("Enter 'course list' to view all courses");
					System.out.println("Enter 'full courses' to view all full courses");
					System.out.println("Enter 'write to file' to write to file all full courses");
					System.out.println("Enter 'students' to view registered students in a course");
					System.out.println("Enter 'special student' to view all courses a student is registered to");
					System.out.println("Enter 'sort' to sort courses");
					System.out.println("Enter 'logout' to logout");
					String input3 = in.readLine();
					
					if (input3.contentEquals("course list")) {
						admin.viewCourses();
					} else if (input3.contentEquals("full courses")) {
						admin.viewFullCourses();
					} else if (input3.contentEquals("write to file")) {
						admin.writeToFileFull();
					} else if (input3.contentEquals("students")) {
						admin.viewRegisteredStudents();
					} else if (input3.contentEquals("special student")) {
						admin.viewStudentCourses();
					} else if (input3.contentEquals("sort")) {
						admin.sortCourses();
					} else {
						System.out.println("Goodbye");
						exit = true;
						serialization();

						}
					}
				else {
					System.out.println("Goodbye");
					exit = true;
					serialization();
					}
				}
			
				else if(input.contentEquals("student")) {
				System.out.println("What is your first name?");
				String fName = in.readLine();
				System.out.println("What is your last name?");
				String lName = in.readLine();
			
				Student student = new Student(fName, lName);
			
				if((student.getUsername() == null || (student.getPassword() == null))) {
					System.out.println("What is your username?");
					String u = in.readLine();
					System.out.println("What is your password?");
					String p = in.readLine();
					for(int i=0;i<Admin.masterList.size();i++) {
						Admin.masterList.get(i).setUsername(u);
						Admin.masterList.get(i).setPassword(p);
					}
				System.out.println("Your username and password have been created");
				serialization();
			}
			
			System.out.println("What is your username?");
			String u = in.readLine();
			System.out.println("What is your password?");
			String p = in.readLine();
			
			System.out.println("Enter 'view all' to view all courses");
			System.out.println("Enter 'view open' to view all open courses");
			System.out.println("Enter 'register' to register to a course");
			System.out.println("Enter 'withdraw' to withdraw from a course");
			System.out.println("Enter 'view registered' to view all cegistered courses");
			System.out.println("Enter 'logout' to logout");
			String input3 = in.readLine();
			
			if (input3.contentEquals("view all")) {
				student.studentViewCourses();
			} else if (input3.contentEquals("view open")) {
				student.openCourses();
			} else if (input3.contentEquals("register")) {
				student.register();
			} else if (input3.contentEquals("withdraw")) {
				student.withdraw();
			} else if (input3.contentEquals("view registered")) {
				student.viewRegisteredCourses();
			} else {
				System.out.println("Goodbye");
				serialization();
				}
			}
		else {
			exit = true;
			serialization();

		}
	}
}
	
	public String print() {
		String names = "";

		if (studentList != null) {
			for (int i = 0; i < studentList.size(); i++) {
				String addFirst = studentList.get(i).getFirstName();
				String addLast = studentList.get(i).getLastName();
				names = names + addFirst + " " + addLast + ", ";
			}
			System.out.println("Course: " + courseName + "\n" + "Course ID: " + courseId + "\n"
					+ "Maximum # of Students: " + maxStudents + "\n" + "Current # of Students: " + registeredStudents
					+ "\n" + "Registered Students: " + names + "\n" + "Instructor: " + instructor + "\n"
					+ "Section: " + sectionNumber + "\n" + "Location: " + location);
			System.out.println("--------------------");
			String text1 = "Course: " + courseName + "\n" + "Course ID: " + courseId + "\n" + "Maximum # of Students: "
					+ maxStudents + "\n" + "Current # of Students: " + registeredStudents + "\n" + "Registered Students: "
					+ names + "\n" + "Instructor: " + instructor + "\n" + "Section: " + courseId + "\n"
					+ "Location: " + location;
			return (text1);
		} else {
			System.out.println("Course: " + courseName + "\n" + "Course ID: " + courseId + "\n"
					+ "Maximum # of Students: " + maxStudents + "\n" + "Current # of Students: " + registeredStudents
					+ "\n" + "Registered Students: " + studentList + "\n" + "Instructor: " + instructor + "\n"
					+ "Section: " + courseId + "\n" + "Location: " + location);
			System.out.println("--------------------");
			String text2 = "Course: " + courseName + "\n" + "Course ID: " + courseId + "\n" + "Maximum # of Students: "
					+ maxStudents + "\n" + "Current # of Students: " + registeredStudents + "\n" + "Registered Students: "
					+ studentList + "\n" + "Instructor: " + instructor + "\n" + "Section: " + courseId + "\n"
					+ "Location: " + location;
			return (text2);
		}
	}

	public String studentPrint() {
		System.out.println("Course: " + courseName + "\n" + "Course ID: " + courseId + "\n" + "Maximum # of Students: "
				+ maxStudents + "\n" + "Current # of Students: " + registeredStudents + "\n" + "Registered Students: "
				+ "\n" + "Instructor: " + instructor + "\n" + "Section: " + courseId + "\n" + "Location: "
				+ location);
		System.out.println("==========");
		String text = "Course: " + courseName + "\n" + "Course ID: " + courseId + "\n" + "Maximum # of Students: "
				+ maxStudents + "\n" + "Current # of Students: " + registeredStudents + "\n" + "Registered Students: "
				+ "\n" + "Instructor: " + instructor + "\n" + "Section: " + courseId + "\n" + "Location: "
				+ location;
		return (text);
	}

	
	
	public String getCourseName() {
		return courseName;
	}


	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}


	public String getCourseId() {
		return courseId;
	}


	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}


	public int getMaxStudents() {
		return maxStudents;
	}


	public void setMaxStudents(int maxStudents) {
		this.maxStudents = maxStudents;
	}


	public int getRegisteredStudents() {
		return registeredStudents;
	}


	public void setRegisteredStudents(int registeredStudents) {
		this.registeredStudents = registeredStudents;
	}


	public String getInstructor() {
		return instructor;
	}


	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}


	public int getSectionNumber() {
		return sectionNumber;
	}


	public void setSectionNumber(int sectionNumber) {
		this.sectionNumber = sectionNumber;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}

	public ArrayList<Student> getStudentList() {
		return studentList;
	}

	public void setStudentList(ArrayList<Student> studentList) {
		this.studentList = studentList;
	}

	public ArrayList<Course> getCourseList() {
		return courseList;
	}

	public void setCourseList(ArrayList<Course> courseList) {
		this.courseList = courseList;
	}
	
}
