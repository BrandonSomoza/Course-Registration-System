package CourseRegistrationSystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Student extends User implements StudentInterface {

//	public Student(String name, String id, int max, int students, String i, int number, String loc) {
//		super(name, id, max, students, i, number, loc);
//		// TODO Auto-generated constructor stub
//	}
	
	public Student (String firstName, String lastName) {
		super(firstName, lastName);
	}

	@Override
	public void studentViewCourses() {
		// TODO Auto-generated method stub
		for(int i=0; i<courseList.size();i++) {
			courseList.get(i).studentPrint();
		}
		
	}

	@Override
	public void openCourses() {
		// TODO Auto-generated method stub
		for(int i=0;i<courseList.size();i++) {
			if(courseList.get(i).getRegisteredStudents() != courseList.get(i).getMaxStudents()) {
				courseList.get(i).studentPrint();
			}
		}
		
	}

	@Override
	public void register() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What is the course name: ");
		String name = in.readLine();
		System.out.println("What is the course ID: ");
		String id = in.readLine();
		System.out.println("Enter your first name: ");
		String firstName = in.readLine();
		System.out.println("Enter your last name: ");
		String lastName = in.readLine();

		for (int i = 0;i < courseList.size();i++) {
			if (courseList.get(i).getCourseName() == name && courseList.get(i).getCourseId() == id) {
				Student student = new Student(firstName, lastName);
				courseList.get(i).studentList.add(student);
				System.out.println("You have been added to the course");
			}
		}
	}

	@Override
	public void withdraw() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What is the course name: ");
		String name = in.readLine();
		System.out.println("What is the course ID: ");
		String id = in.readLine();
		System.out.println("Enter your first name: ");
		String firstName = in.readLine();
		System.out.println("Enter your last name: ");
		String lastName = in.readLine();

		for (int i = 0;i < courseList.size();i++) {
			if (courseList.get(i).getCourseName() == name && courseList.get(i).getCourseId() == id) {
				Student student = new Student(firstName, lastName);
				courseList.get(i).studentList.remove(student);
				System.out.println("You have been removed from the course");
			}
		}
	}

	@Override
	public void viewRegisteredCourses() {
		// TODO Auto-generated method stub
		System.out.println("These are the courses you are registered in:");
		for(int i=0;i<studentList.size();i++) {
			System.out.println(studentList.get(i).getCourseName());
		}
	}

}
