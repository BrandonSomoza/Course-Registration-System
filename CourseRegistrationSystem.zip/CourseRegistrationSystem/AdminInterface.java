package CourseRegistrationSystem;

import java.io.IOException;
import java.util.ArrayList;

public interface AdminInterface {
	public void createCourse() throws IOException;
	public void deleteCourse() throws IOException;
	public void editCourse() throws IOException;
	public void displayCourse() throws IOException;
	public void registerStudent() throws IOException;
	public void viewCourses();
	public ArrayList<Course> viewFullCourses();
	public void writeToFileFull();
	public void viewRegisteredStudents() throws IOException;
	public void viewStudentCourses() throws IOException;
	public void sortCourses();
}
